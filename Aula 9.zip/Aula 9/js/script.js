 /*var num1; alert("Hello world!")
 
 let num2;

 num3 = 3

 const pi = 3.14
 aritmeticos => + - * / \\ % ** ++ --
 logicos=> && || ! 
 comparacao = > < >= <= != == ===
 atribuicao => += -= *= /=
 */




 function boasVindas(){
    //alert("Seja bem vindo!")
    document.write("Seja bem vindo!!");
 }

 function somar(){
   // Valor01 = parseInt(document.frmCalc.intValor1.value); //parseInt é pra deixar como inteiro//
   // Valor02 = parseInt(document.getElementById("intValor2").value); // Os dois são a msm coisa//
    
    Valor01 = document.getElementById("txtValor1");
    Valor02 = document.getElementById("txtValor2");
    result = document.getElementById("result");

    if(Valor01.value == ""){
        alert("Campo obrigatório");
        Valor01.focus();
        return false;
    }

    soma = parseInt(Valor01.value) + parseInt(Valor02.value);

    result.innerText = soma;
 }