import Card, { Auxiliar } from "./components/Card/page";
import Meucomponente from "./components/Meucomponente/page";

//Para exportar funções sem ser a padrão n usa o "default"//
export default function Home(){
  return(
    <>
      <h1>Hello world!</h1>   

      <Card />

      <Meucomponente />

      <Auxiliar />

    </>
  )
}