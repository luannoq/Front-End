//Comentário fora do return//
const Meucomponente = () =>{
    return(
        <>
            {/*Criando Arrow Function, outro jeito de criar uma função*/}
            <h1>Meu componente</h1>
        </>
    )

}
export default Meucomponente