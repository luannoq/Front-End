export default function Header(){
    return(
        <>
            <header style={{width:'100%', backgroundColor: 'blue', height: '50px'}}>Cabeçalho</header>
        </>
    )
}