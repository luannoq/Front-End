function contadorPalavras(frase){
    let palavras = frase.trim().split(/\s+/); //Trim tira os espaços da frase.
    //Split converte cada palavra para um indice no array.

    return frase.trim()=== " " ? 0 : palavras.length; // funciona como if e else o ternário
}

document.getElementById('texto').addEventListener("input", function(){
    let texto = this.value;
    let totalPalavras = contadorPalavras(texto);
    document.getElementById('contador').innerText = totalPalavras
})

function contarCaracteres(frase){
    return frase.length;
}

document.getElementById('texto').addEventListener("input", function(){
    let texto = this.value
    let totalPalavras = contadorPalavras(texto);
    let totalCaracteres = contarCaracteres(texto);
    document.getElementById('contador').innerText = totalPalavras
    document.getElementById('contadorCaracteres').innerText = totalCaracteres
})
