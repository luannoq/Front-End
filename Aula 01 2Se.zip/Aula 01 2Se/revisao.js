function soma(x,y){
    return x + y
}

document.getElementById('frmSoma').addEventListener('submit', function (event){
    event.preventDefault();// Evita o carregamento da página 
    let num1  = parseFloat(document.getElementById('numero1').value);
    let num2 = parseFloat(document.getElementById('numero2').value);
    
    let resultado = soma(num1 , num2);

    document.getElementById('resultado').innerText = `Soma: ${resultado}`;

})