import CompProduto from "@/components/compProduto/compProduto";

const Produto= ()=>{
    return(
        <>
            
            <CompProduto />
        </>
    )
}
export default Produto;