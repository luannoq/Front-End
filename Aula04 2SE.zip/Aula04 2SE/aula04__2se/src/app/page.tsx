const Home = ()=>{

  return(
    <>
      <h1>Página inicial</h1>
    
    
    </>

  )
}
export default Home;