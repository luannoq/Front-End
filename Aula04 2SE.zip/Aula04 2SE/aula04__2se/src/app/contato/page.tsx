import CompContato from "@/components/compContato/compContato";

const Contato= ()=> {
    return(
        <>
            <CompContato />
        </>
    )
}
export default Contato;