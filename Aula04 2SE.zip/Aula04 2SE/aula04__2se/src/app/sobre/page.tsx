import CompSobre from "@/components/compSobre/compSobre";

const Sobre = ()=> {

    return(
        <>
        
            <h1>Sobre</h1>
            <CompSobre />
        
        
        </>




    )

}
export default Sobre;