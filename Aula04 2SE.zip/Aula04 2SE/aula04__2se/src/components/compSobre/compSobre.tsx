const CompSobre= ()=>{
    return(
        <>
        
        
        
        </>

    )
}
export default CompSobre;