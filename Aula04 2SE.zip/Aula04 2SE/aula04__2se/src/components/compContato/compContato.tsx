const CompContato= ()=> {
    return(
        <>
            <h1>Contato</h1>
        </>
    )
}
export default CompContato;