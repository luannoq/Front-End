import Menu from "../menu/menu";

const Header = ()=>{

    return(
        <>
            <header>
                <h1>Cabeçalho</h1>
                <Menu />

            </header>
        
        
        </>

    )
}
export default Header;