import Image from "next/image";
const CompProduto= ()=>{
    return(
        <>
            
            <Image src="/Images/8pedaladas.jpg" alt="8Pedaladas" width={100} height={100} />
        
        </>

    )
}
export default CompProduto;