import Link from "next/link";

const Menu= ()=>{
    return(
        <>
            <ul className="menu">
                <li><Link href="/produto">Produto</Link></li>
                <li><Link href="/">Home</Link></li>  
                {/* Quando se trata de voltar para a página home, só se usa a / */}
                <li><Link href="/contato">Contato</Link></li>
                <li><Link href="/sobre">Sobre</Link></li>


            </ul>
        </>
    )
}
export default Menu;