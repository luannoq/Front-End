const Footer= ()=>{
    return(
        <>
            <h1>Rodape</h1>
        </>



    )
}
export default Footer;