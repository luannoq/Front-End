'use client'

import { useState } from "react";

 export default function Home(){

  const [valor, setValor] = useState(0)

  const[dados, setDados] = useState("");

  const [nome, setNome] = useState("");

  const [conteudo, setConteudo] = useState("");

  const [mensagem, setMensagem] = useState(" Clique no botão para alterar a mensagem!");

  const [alterar, setAlterar] = useState ("")

  const handleChange = (event :React.ChangeEvent<HTMLInputElement>) =>{
    setDados(event.target.value)

  }

  const nomeDigitado = (event :React.ChangeEvent<HTMLInputElement>)=>{
    setNome(event.target.value)
  }

  const exibirConteudo = () =>{
    setConteudo(nome);
    setNome("");
  }

  const trocarMensagem = () =>{
    setMensagem("Mensagem alterada!")
  }

  const alterar = () =>{
    setAlterar(" Clique no botão para alterar a mensagem! ")
  }


  return(
    <>
      <h1>Trabalhando com useState</h1>

      <h2>Exemplo 01 </h2>

      <button onClick={()=> {setValor(valor + 1)}} >Incrementar</button>
      <button onClick={()=> {setValor(valor - 1)}} disabled={valor == 0} >Decrementar</button>
      <button onClick={()=> {setValor(0)}} >Igual a zero</button>
      <p>Novo valor: {valor}</p>


      <h2>Exemplo 02 </h2>

      Dados: <input value={dados} onChange={handleChange}></input>
      <p>Valor digitado: {dados} </p>

      <h3>Exemplo 03</h3>

      <form>
        Nome: <input value={nome} onChange={nomeDigitado} ></input>
        <button type="button" onClick={exibirConteudo}>Enviar</button> {/*Inibir o envio do formulário*/ }
        <p>Nome digitado:{conteudo} </p>
      </form>
      
      <h3>Exemplo 04</h3>

      <p>Mensagem:{mensagem} </p>
      <button onClick={trocarMensagem}>Trocar</button> {/*Paramos na parte de fazer retornar a mensagem original*/}
    
    </>
  );
 }